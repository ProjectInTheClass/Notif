const mysql = require('mysql');

var connection = mysql.createConnection({
    host : 'noti.c0pwj79j83nj.ap-northeast-2.rds.amazonaws.com',
    user : 'admin',
    password: 'notinoti',
    port : 3306,
    database : 'noti'
});

exports.handelr = function (event, context, callback) {
    const mysql = require('mysql');
    var sql = 'SELECT * FROM Cards;';
    connection.query(sql, function(err, rows, fields) {
        connection.end();
        if(err) {
            console.log(err);
        } else {
            console.log(rows);   
        }
    });
}